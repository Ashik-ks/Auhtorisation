document.addEventListener('DOMContentLoaded', () => {
    const uploadbutton = document.getElementById('uploadbutton');
    const videoupload = document.getElementById('videoupload');
    const videolist = document.getElementById('videolist');
    const videoplayer = document.getElementById('videoplayer');
    const videosource = document.getElementById('videosource');
  
    // Load the list of videos when the page loads
    fetchVideos();
  
    // Upload video when the button is clicked
    uploadbutton.addEventListener('click', () => {
      const file = videoupload.files[0];
      if (file) {
        const reader = new FileReader();
  
        // Convert the video file to Base64 format
        reader.onloadend = function () {
          const base64Video = reader.result.split(',')[1];
  
          // Send the video to the server using fetch
          fetch('/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ video: base64Video }),
          })
          .then(response => response.json())
          .then(data => {
            alert(data.message);
            fetchVideos(); // Refresh the list of videos
          })
          .catch(error => console.error('Error uploading video:', error));
        };
  
        reader.readAsDataURL(file); // Read the file as a Base64 string
      } else {
        alert('Please select a video to upload');
      }
    });
  
    // Fetch and display the list of videos from the server
    function fetchVideos() {
      fetch('/upload')
        .then(response => response.json())
        .then(videos => {
          videolist.innerHTML = '';
          videos.forEach(video => {
            const li = document.createElement('li');
            li.textContent = video;
            li.addEventListener('click', () => {
              videosource.src = `/videos/${videofile}`;
              videoplayer.load(); // Reload the video player with the new source
            });
            videolist.appendChild(li);
          });
        })
        .catch(error => console.error('Error fetching videos:', error));
    }
  });
  